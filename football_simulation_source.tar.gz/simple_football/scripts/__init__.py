"""
Scripts for running football match simulations.
"""

# Script utilities can be added here
__all__ = []
