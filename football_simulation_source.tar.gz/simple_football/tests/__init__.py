"""
Test suite for simple_football_sim package.
Validates schema completeness, timestamp ordering, and role rules compliance.
"""

# Test utilities and shared fixtures can be added here
__all__ = []
